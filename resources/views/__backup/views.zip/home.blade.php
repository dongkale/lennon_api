@extends('layouts.master')

@section('content')
<div class="container">
    <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="row">
            <div class="col-md-3 col-sm-3 col-xs-3">
                <div style="background-color:#9E2121; height:200px;">@yield('content')</div>
            </div>
            <div class="col-md-9 col-sm-9 col-xs-9">
                 <div style="background-color:#55A03D; height:600px;">@yield('content')</div>
            </div>
        </div>
    </div>
</div> 
@endsection 