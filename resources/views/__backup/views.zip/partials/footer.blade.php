<footer class="pt-5 my-5 text-muted">
  Created by <a href="https://codeanddeploy.com">Code And Deploy</a> &middot; &copy; {{ date('Y') }}
</footer>